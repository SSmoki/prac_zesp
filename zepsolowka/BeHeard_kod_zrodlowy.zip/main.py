# Do cwiczenia a nastepnie przewidywania odpalic:
# 1. makeFolders() - Tworzy katalogi
# 2. readSequences() - Zapisuje w nich sekwencje
# 3. trainedModel = labelAndTrain() - Cwiczy model i przypisuje go do zmiennej trainedModel
# 4. predictFromModel() - Przewiduje na podstawie modelu ze zmiennej trainedModel
#
# Aby wgrac i uruchomic wycwiczony wczesniej model
# trainedModel = restoreModel()
# predictFromModel()

import os
from math import *
import mediapipe as mp
import numpy as np
import cv2
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.callbacks import TensorBoard

# Lista gestow/znakow i sciezka folderu
actions = np.array(
    ['dziendobry', 'chce', 'przedluzyc', 'legitymacje', 'nazywamsie', 'numer', 'moj', 'wniosek', 'dac', 'ile',
     'kosztuje', 'godzina', 'kiedy', 'bedzie', 'decyzja', 'warunku', 'dziekuje', 'dowidzenia', 'm', 'a', 'k', 's',
     '300', '2', '1'])
translatedActions = np.array(
    ['Dzień dobry!', 'chcę', 'przedłużyć', 'legitymację', 'nazywam się', 'numer', 'mój', 'wniosek', 'dać', 'ile',
     'kosztuje', 'godzina', 'kiedy', 'będzie', 'decyzja', 'warunku', 'Dziękuje', 'Do widzenia!', 'M', 'A', 'K', 'S',
     '300', '2', '1'])

# Ilość sekwencji dla jednego gestu
no_sequences = 30
# Długość sekwencji w klatkach obrazu
sequence_length = 30
# Ilość czasu w ms pomiędzy snapszotami próbek
snaptime = 1000
# Wymiary okna z wyświetlanym obrazem //MEDIAPIPE
winX, winY = 1080, 800
# Prog wykrywania punktow ciala (niska wartosc = wiele nadinterpretacji) //MEDIAPIPE
mdc = 0.5
# Dokladnosc wykrywania punktow ciala (mniej = lepsza wydajnosc kosztem jakosci) //MEDIAPIPE
mtc = 0.5
# Procent probki przeznaczony na testowanie //TENSORFLOW
teS = 0.20
# Ilosc prob dokonanych przez model (wiecej = wieksza skutecznosc przy dluzszym czasie cwiczenia) //TENSORFLOW
epo = 2000
# Po ilu klatkach nastepuje zmiana wyswietlanego tekstu
counterFrames = 10

# Inne zmienne
tekst = ""
global trainedModel
DATA_PATH = os.path.join('tabliceMP')
np.set_printoptions(suppress=True)
# Czcionki uzywane z ich wielkosciami
fontpath = "./PatrickHand.ttf"
# Wielkosc tekstu
fontsize = 2
ft2 = cv2.freetype.createFreeType2()
ft2.loadFontData(fontpath, 0)
areHandsIn = False

# Uruchamiamy model, wybieramy czulosc i inicjujemy rysowanie landmarków na ekranie
mp_holistic = mp.solutions.holistic
holistic_model = mp_holistic.Holistic(
    min_detection_confidence=mdc,
    min_tracking_confidence=mtc
)
mp_drawing = mp.solutions.drawing_utils

# Żródło obrazu, 0 to domyślna kamera
capture = cv2.VideoCapture(0)


def calcPyth(x1, x2, y1, y2, z1, z2):
    x = abs(x1 - x2)
    y = abs(y1 - y2)
    z = abs(z1 - z2)
    return sqrt((x ** 2) + (y ** 2) + (z ** 2))


# Funkcja zapisujaca pozycje wszystkich punktów w aktualnej klatce i zwracajaca tablice xyz
def landmarkSnapshot(results):
    global areHandsIn
    if results.left_hand_landmarks or results.right_hand_landmarks:
        areHandsIn = True
    else:
        areHandsIn = False

    pose = np.array([[res.x, res.y, res.z, res.visibility] for res in
                     results.pose_landmarks.landmark]).flatten() if results.pose_landmarks else np.ones(33 * 4)
    lh = np.array([[res.x, res.y, res.z] for res in
                   results.left_hand_landmarks.landmark]).flatten() if results.left_hand_landmarks else np.ones(21 * 3)
    rh = np.array([[res.x, res.y, res.z] for res in
                   results.right_hand_landmarks.landmark]).flatten() if results.right_hand_landmarks else np.ones(
        21 * 3)
    landmarks3D = []
    lhDiv = 1 + calcPyth(lh[0], lh[3], lh[1], lh[4], lh[2], lh[5])
    for i in range(0, 63, 3):
        for j in range(i, 63, 3):
            landmarks3D.append(calcPyth(lh[i], lh[j], lh[i + 1], lh[j + 1], lh[i + 2], lh[j + 2]) / lhDiv)
    rhDiv = 1 + calcPyth(rh[0], rh[3], rh[1], rh[4], rh[2], rh[5])
    for i in range(0, 63, 3):
        for j in range(i, 63, 3):
            landmarks3D.append(calcPyth(rh[i], rh[j], rh[i + 1], rh[j + 1], rh[i + 2], rh[j + 2]) / rhDiv)
    lhxrhDiv = 1 + calcPyth(rh[0], lh[0], rh[1], lh[1], rh[2], lh[2])
    for i in range(0, 63, 3):
        for j in range(0, 63, 3):
            landmarks3D.append(calcPyth(rh[i], lh[j], rh[i + 1], lh[j + 1], rh[i + 2], lh[j + 2]) / lhxrhDiv)
    poseDiv = 1 + calcPyth(pose[28], pose[32], pose[29], pose[33], pose[30], pose[34])
    for i in range(28, 80, 4):
        for j in range(i, 80, 4):
            landmarks3D.append(calcPyth(pose[i], pose[j], pose[i + 1], pose[j + 1], pose[i + 2], pose[j + 2]) / poseDiv)
    return np.array(landmarks3D)


# Funkcja tworzaca podkatalogi dla gestow do cwiczenia
def makeFolders():
    for action in actions:
        for sequence in range(no_sequences):
            try:
                os.makedirs(os.path.join(DATA_PATH, action, str(sequence)))
            except:
                pass


# Tworzymy mapę etykiet a nastepnie cwiczymy model
def labelAndTrain():
    if os.path.exists("action.h5"):
        os.remove("action.h5")

    label_map = {label: num for num, label in enumerate(actions)}
    sequences, labels = [], []
    for action in actions:
        for sequence in range(no_sequences):
            window = []
            for frame_num in range(sequence_length):
                res = np.load(os.path.join(DATA_PATH, action, str(sequence), "{}.npy".format(frame_num)))
                window.append(res)
            sequences.append(window)
            labels.append(label_map[action])

    X = np.array(sequences)
    Y = to_categorical(labels).astype(int)
    # Ustawiamy jaki procent danych będzie używany do trenowania a jaki do testowania
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=teS)

    # Tworzymy sciezke z logami do obserwacji cwiczenia
    log_dir = os.path.join('Logi')
    tb_callback = TensorBoard(log_dir=log_dir)

    # Ladujemy dane i cwiczymy
    model = Sequential()
    # W input_shape opisujemy jak wygladaja dostarczane przez nas dane, tutaj 30 klatek po punktow(33*4+21*3+21*3)
    model.add(LSTM(64, return_sequences=True, activation='relu', input_shape=(sequence_length, 994)))
    model.add(LSTM(128, return_sequences=True, activation='relu'))
    model.add(LSTM(64, return_sequences=False, activation='relu'))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(32, activation='relu'))
    # Softmax dziala na zasadzie znormalizowanego prawdopodobienstwa, tj. dla kazdej mozliwej wartosci pokazuje
    # prawdopodobienstwo bdace jaka czescia procentowa wartosci 1
    model.add(Dense(actions.shape[0], activation='softmax'))
    model.compile(optimizer='Adam', loss='categorical_crossentropy', metrics=['categorical_accuracy'])
    model.fit(X_train, Y_train, epochs=epo, callbacks=[tb_callback])
    print(model.summary())

    # Zapisujemy model
    model.save('action.h5')
    return model


# Przywraca model z pliku i go zwraca
def restoreModel():
    model = Sequential()
    model.add(LSTM(64, return_sequences=True, activation='relu', input_shape=(sequence_length, 994)))
    model.add(LSTM(128, return_sequences=True, activation='relu'))
    model.add(LSTM(64, return_sequences=False, activation='relu'))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(32, activation='relu'))
    model.add(Dense(actions.shape[0], activation='softmax'))
    model.compile(optimizer='Adam', loss='categorical_crossentropy', metrics=['categorical_accuracy'])
    model.load_weights('action.h5')
    return model


def readSequences():
    # Petla działająca dla każdego gestu, próby i klatki...
    for action in actions:
        for sequence in range(no_sequences):
            for frame_num in range(sequence_length):

                # Typ odczytu(tutaj klatka po klatce z kamerki)
                ret, frame = capture.read()

                # Rozmiar okna
                frame = cv2.resize(frame, (winX, winY))

                # BGR >> RGB
                image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                # Wybieramy model MediaPipe
                image.flags.writeable = False
                results = holistic_model.process(image)
                image.flags.writeable = True

                # RGB >> BGR
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                # Prawa Reka
                mp_drawing.draw_landmarks(
                    image,
                    results.right_hand_landmarks,
                    mp_holistic.HAND_CONNECTIONS
                )

                # Lewa Reka
                mp_drawing.draw_landmarks(
                    image,
                    results.left_hand_landmarks,
                    mp_holistic.HAND_CONNECTIONS
                )

                # Ciało
                mp_drawing.draw_landmarks(
                    image,
                    results.pose_landmarks,
                    mp_holistic.POSE_CONNECTIONS, )

                if frame_num == 0:
                    cv2.putText(image, 'Gest: {} | Plik Video: {}/{}'.format(action, sequence + 1, no_sequences),
                                (10, 37), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 5)
                    cv2.putText(image, 'Gest: {} | Plik Video: {}/{}'.format(action, sequence + 1, no_sequences),
                                (10, 37), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
                    cv2.putText(image, 'Przygotuj sie do nastepnej sekwencji', (50, 125), cv2.FONT_HERSHEY_COMPLEX,
                                1.38, (255, 255, 255), 5)
                    cv2.putText(image, 'Przygotuj sie do nastepnej sekwencji', (50, 125), cv2.FONT_HERSHEY_COMPLEX,
                                1.38, (0, 0, 255), 2)
                    cv2.imshow("Zczytywanie sekwencji", image)
                    # Dlugosc pauzy pomiedzy odczytami w ms
                    cv2.waitKey(snaptime)
                else:
                    cv2.putText(image, 'Gest: {} | Plik Video: {}/{}'.format(action, sequence + 1, no_sequences),
                                (10, 37), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 5)
                    cv2.putText(image, 'Gest: {} | Plik Video: {}/{}'.format(action, sequence + 1, no_sequences),
                                (10, 37), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
                    cv2.imshow("Zczytywanie sekwencji", image)

                # Zapisujemy zrzut punktów do pliku
                keypoints = landmarkSnapshot(results)
                npy_path = os.path.join(DATA_PATH, action, str(sequence), str(frame_num))
                np.save(npy_path, keypoints)

                # "k" aby zakończyć
                if cv2.waitKey(5) & 0xFF == ord('k'):
                    break

    # Zamykamy przechwytywanie i okno
    cv2.destroyAllWindows()


# Funkcja do przewidywania gestów(TYLKO Z WYCWICZONYM MODELEM!!!)
def predictFromModel():
    sequence = []
    counter = counterFrames
    resBuffer = np.zeros(np.size(actions))
    accuracy = 0
    global areHandsIn

    # Petla działająca tak długo jak zczytujemy obraz z kamerki
    while capture.isOpened():

        # Typ odczytu(tutaj klatka po klatce z kamerki)
        ret, frame = capture.read()

        # Rozmiar okna
        frame = cv2.resize(frame, (winX, winY))

        # BGR >> RGB
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Wybieramy model MediaPipe
        image.flags.writeable = False
        results = holistic_model.process(image)
        image.flags.writeable = True

        # RGB >> BGR
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        # # Prawa Reka
        # mp_drawing.draw_landmarks(
        #     image,
        #     results.right_hand_landmarks,
        #     mp_holistic.HAND_CONNECTIONS
        # )
        #
        # # Lewa Reka
        # mp_drawing.draw_landmarks(
        #     image,
        #     results.left_hand_landmarks,
        #     mp_holistic.HAND_CONNECTIONS
        # )
        #
        # # Ciało
        # mp_drawing.draw_landmarks(
        #     image,
        #     results.pose_landmarks,
        #     mp_holistic.POSE_CONNECTIONS, )

        # Odczyt z modelu
        keypoints = landmarkSnapshot(results)
        sequence.append(keypoints)
        sequence = sequence[-sequence_length:]

        if len(sequence) == sequence_length and areHandsIn:
            res = trainedModel.predict(np.expand_dims(sequence, axis=0))[0]
            resBuffer += res
            if counter == counterFrames:
                print(list(translatedActions[x] for x in np.argpartition(resBuffer, -3)[-3:]))
                print(list(
                    str(int(resBuffer[x] * 100 / counterFrames)) + "%" for x in np.argpartition(resBuffer, -3)[-3:]))
                gesture = translatedActions[np.argmax(resBuffer)]
                accuracy = int((np.max(resBuffer) / counterFrames) * 100)
                counter = 0
                resBuffer = np.zeros(np.size(actions))
            counter += 1

            textsize = ft2.getTextSize(str(gesture), 100, -1)[0]
            FTtextX = (winX - textsize[0]) / 2
            FTtextY = ((winY + textsize[1]) / 2) + 225
            ft2.putText(image, str(gesture), (int(FTtextX), int(FTtextY)), fontHeight=100, color=(255, 255, 255),
                        thickness=5, line_type=cv2.LINE_4, bottomLeftOrigin=False)
            ft2.putText(image, str(gesture), (int(FTtextX), int(FTtextY)), fontHeight=100, color=(130, 79, 12),
                        thickness=-1, line_type=cv2.LINE_4, bottomLeftOrigin=False)

            ft2.putText(image, str(accuracy) + "%", (int(FTtextX) - 50, int(FTtextY) + 10), fontHeight=30,
                        color=(255, 255, 255), thickness=2, line_type=cv2.LINE_4, bottomLeftOrigin=False)
            ft2.putText(image, str(accuracy) + "%", (int(FTtextX) - 50, int(FTtextY) + 10), fontHeight=30,
                        color=(130, 79, 12), thickness=-1, line_type=cv2.LINE_4, bottomLeftOrigin=False)
        else:
            textsize = ft2.getTextSize(str("<nie wykryto dłoni>"), 50, -1)[0]
            FTtextX = (winX - textsize[0]) / 2
            FTtextY = ((winY + textsize[1]) / 2) + 300
            ft2.putText(image, str("<nie wykryto dłoni>"), (int(FTtextX), int(FTtextY)), fontHeight=50,
                        color=(255, 255, 255), thickness=5, line_type=cv2.LINE_4, bottomLeftOrigin=False)
            ft2.putText(image, str("<nie wykryto dłoni>"), (int(FTtextX), int(FTtextY)), fontHeight=50,
                        color=(0, 0, 255), thickness=-1, line_type=cv2.LINE_4, bottomLeftOrigin=False)

        ft2.putText(image, str("<< [ESC]"), (int(9), int(9)), fontHeight=30, color=(255, 255, 255), thickness=2,
                    line_type=cv2.LINE_4, bottomLeftOrigin=False)
        ft2.putText(image, str("<< [ESC]"), (int(10), int(10)), fontHeight=30, color=(0, 0, 255), thickness=-1,
                    line_type=cv2.LINE_4, bottomLeftOrigin=False)

        # Wyświetla okno z obrazem
        cv2.imshow("BeHeard - Rozpoznawanie Jezyka Migowego", image)

        # "k" aby zakończyć program
        k = cv2.waitKey(1)
        if k == 27:
            break

    # Zamykamy przechwytywanie i okno
    capture.release()
    cv2.destroyAllWindows()


# # Aby nagrac sekwencje:
# makeFolders() # Tworzy katalogi
# readSequences() # Zapisuje w nich sekwencje w postaci tablic koordynatow

# # Aby wycwiczyc model:
# trainedModel = labelAndTrain() # Cwiczy model i przypisuje go do zmiennej trainedModel
# predictFromModel() # Przewiduje na podstawie modelu ze zmiennej trainedModel

# Aby wgrac i uruchomic wycwiczony wczesniej model
trainedModel = restoreModel()
predictFromModel()
